<!-- BEGIN_TF_DOCS -->
## Requirements

No requirements.

## Providers

| Name | Version |
|------|---------|
| <a name="provider_google"></a> [google](#provider\_google) | 6.18.0 |

## Modules

| Name | Source | Version |
|------|--------|---------|
| <a name="module_cmek_keyrings_as1"></a> [cmek\_keyrings\_as1](#module\_cmek\_keyrings\_as1) | ../../modules/fabric/kms | n/a |
| <a name="module_folder_level_iam_bindings"></a> [folder\_level\_iam\_bindings](#module\_folder\_level\_iam\_bindings) | ../../modules/cft/terraform-google-iam/modules/folders_iam | n/a |
| <a name="module_folders"></a> [folders](#module\_folders) | ../../modules/fabric/folder | n/a |
| <a name="module_project_level_iam_bindings"></a> [project\_level\_iam\_bindings](#module\_project\_level\_iam\_bindings) | ../../modules/cft/terraform-google-iam/modules/projects_iam | n/a |
| <a name="module_projects"></a> [projects](#module\_projects) | ../../modules/fabric/project | n/a |

## Resources

| Name | Type |
|------|------|
| [google_logging_project_cmek_settings.kms_service_account_id](https://registry.terraform.io/providers/hashicorp/google/latest/docs/data-sources/logging_project_cmek_settings) | data source |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_business_unit"></a> [business\_unit](#input\_business\_unit) | business unit a project belongs to | `string` | n/a | yes |
| <a name="input_cmek"></a> [cmek](#input\_cmek) | project- and region-specific CMEKs for all resource types | `map(map(string))` | n/a | yes |
| <a name="input_folder_level_iam_bindings"></a> [folder\_level\_iam\_bindings](#input\_folder\_level\_iam\_bindings) | folder-level IAM bindings for groups | `map(map(list(string)))` | n/a | yes |
| <a name="input_folders"></a> [folders](#input\_folders) | list of folders to create | <pre>map(object(<br/>    {<br/>      budget_alerts = object({<br/>        billing_account_name = string<br/>        alerts = map(object({<br/>          amount = object({<br/>            currency_code   = optional(string)<br/>            nanos           = optional(number)<br/>            units           = optional(number)<br/>            use_last_period = optional(bool)<br/>          })<br/>          filter = optional(object({<br/>            credit_types_treatment = optional(object({<br/>              exclude_all       = optional(bool)<br/>              include_specified = optional(list(string))<br/>            }))<br/>            label = optional(object({<br/>              key   = string<br/>              value = string<br/>            }))<br/>            period = optional(object({<br/>              calendar = optional(string)<br/>              custom = optional(object({<br/>                start_date = object({<br/>                  day   = number<br/>                  month = number<br/>                  year  = number<br/>                })<br/>                end_date = optional(object({<br/>                  day   = number<br/>                  month = number<br/>                  year  = number<br/>                }))<br/>              }))<br/>            }))<br/>            services = optional(list(string))<br/>          }))<br/>          threshold_rules = optional(list(object({<br/>            percent          = number<br/>            forecasted_spend = optional(bool)<br/>          })), [])<br/>        }))<br/>      })<br/>      default_log_sink_exclusions = optional(map(string), {})<br/>      deletion_protection         = optional(bool, false)<br/>      essential_contacts          = optional(map(list(string)), {})<br/>      hierarchical_firewall_policies = optional(map(object({<br/>        rules = map(object({<br/>          action         = string<br/>          direction      = string<br/>          enable_logging = optional(bool, false)<br/>          match = object({<br/>            src_ip_ranges  = optional(list(string), [])<br/>            dest_ip_ranges = optional(list(string), [])<br/>            layer4_config = object({<br/>              ip_protocol = optional(string, "tcp")<br/>              ports       = optional(list(number), [])<br/>            })<br/>          })<br/>          priority                = number<br/>          target_resources        = optional(list(string), [])<br/>          target_service_accounts = optional(list(string), [])<br/>        }))<br/>      })), {})<br/>      tag_bindings = optional(map(string), {})<br/>    }<br/>  ))</pre> | n/a | yes |
| <a name="input_labels_common"></a> [labels\_common](#input\_labels\_common) | common labels for every resource | `map(string)` | n/a | yes |
| <a name="input_parent_folder_id"></a> [parent\_folder\_id](#input\_parent\_folder\_id) | ID of the Mutual Funds BU folder | `string` | n/a | yes |
| <a name="input_project_common"></a> [project\_common](#input\_project\_common) | settings common to all projects | `any` | n/a | yes |
| <a name="input_project_level_iam_bindings"></a> [project\_level\_iam\_bindings](#input\_project\_level\_iam\_bindings) | project-level IAM bindings for groups | `map(map(list(string)))` | n/a | yes |
| <a name="input_projects"></a> [projects](#input\_projects) | list of projects to create | <pre>list(object(<br/>    {<br/>      activate_apis        = list(string)<br/>      billing_account_name = string<br/>      budget_alerts = optional(map(object({<br/>        amount = object({<br/>          currency_code   = optional(string)<br/>          nanos           = optional(number)<br/>          units           = optional(number)<br/>          use_last_period = optional(bool)<br/>        })<br/>        filter = optional(object({<br/>          credit_types_treatment = optional(object({<br/>            exclude_all       = optional(bool)<br/>            include_specified = optional(list(string))<br/>          }))<br/>          label = optional(object({<br/>            key   = string<br/>            value = string<br/>          }))<br/>          period = optional(object({<br/>            calendar = optional(string)<br/>            custom = optional(object({<br/>              start_date = object({<br/>                day   = number<br/>                month = number<br/>                year  = number<br/>              })<br/>              end_date = optional(object({<br/>                day   = number<br/>                month = number<br/>                year  = number<br/>              }))<br/>            }))<br/>          }))<br/>          services = optional(list(string))<br/>        }))<br/>        threshold_rules = optional(list(object({<br/>          percent          = number<br/>          forecasted_spend = optional(bool)<br/>        })), [])<br/>      })), {})<br/>      compute_metadata   = optional(map(string), {})<br/>      deletion_policy    = optional(string, "DELETE")<br/>      essential_contacts = optional(map(list(string)), {})<br/>      is_cmek_project    = optional(bool, false)<br/>      labels             = map(string)<br/>      lien_reason        = optional(string)<br/>      parent_folder_desc = string<br/>      project_desc       = string<br/>      tag_bindings       = optional(map(string), {})<br/>      tags = optional(map(object({<br/>        description = optional(string, "Terraform-managed project-level Tag")<br/>        id          = optional(string)<br/>        values      = optional(map(object({ id = optional(string) })), {})<br/>      })), {})<br/>    }<br/>  ))</pre> | n/a | yes |
| <a name="input_rsrc_prefix"></a> [rsrc\_prefix](#input\_rsrc\_prefix) | resource name prefixes according to naming conventions | `map(string)` | n/a | yes |

## Outputs

| Name | Description |
|------|-------------|
| <a name="output_folders"></a> [folders](#output\_folders) | attributes of folders created (ref. - ../modules/fabric/folder/outputs.tf) |
| <a name="output_projects"></a> [projects](#output\_projects) | attributes of projects created (ref. - modules/fabric/project/outputs.tf) |
<!-- END_TF_DOCS -->