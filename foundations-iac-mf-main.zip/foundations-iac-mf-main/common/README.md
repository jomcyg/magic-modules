# General (environment-agnostic) infrastructure

Terraform code (IaC) for MF's general environment-agnostic Google Cloud infrastructure.

## Folder structure

### 01-resource-hierarchy

- env folders
  - delete the Folder Admin IAM bindings - not possible
  - budget alerts
  - modify the exclusion filters of the existing _Default log sink
  - essential contact overrides
  - hierarchical FW policies
  - Tag bindings
- common folder
  - delete the Folder Admin IAM bindings - not possible
  - budget alerts
  - modify the exclusion filters of the existing _Default log sink
  - essential contact overrides
  - hierarchical FW policies
  - Tag bindings
- common projects
  - enable APIs
  - budget alerts
  - disable the _Default log sink
  - delete the Project Owner IAM bindings - not possible
- Cloud KMS keys in the common security project to be used as CMEKs for env-agnostic projects
- org policy overrides at the BU folder and common project level
- groups and their associated IAM bindings at the BU folder and common project level

### Implementation

Resource hierarchy flow (2 `terraform apply` operations):

- step 1
  - create all projects (marking the Shared VPC host projects)
  - create all projects’ CMEKs in the security project
  - run `terraform apply`
- step 2
  - create a variable in the appropriate TFE project’s variable set and populate it with each GC project’s CMEK
- step 3
  - add default log sink attributes in tfvars
  - add Shared VPC service project attributes in tfvars
  - run `terraform apply`

### 02-logging

- log sinks
- log destinations

### 02-security

- Artifact Registry
- Cloud KMS
- Certificate Authority Service (CAS)
