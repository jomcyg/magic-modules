<!-- BEGIN_TF_DOCS -->
## Requirements

No requirements.

## Providers

| Name | Version |
|------|---------|
| <a name="provider_google"></a> [google](#provider\_google) | 6.19.0 |
| <a name="provider_google-beta"></a> [google-beta](#provider\_google-beta) | 6.19.0 |

## Modules

| Name | Source | Version |
|------|--------|---------|
| <a name="module_common_folder_details"></a> [common\_folder\_details](#module\_common\_folder\_details) | ../../modules/fabric/projects-data-source | n/a |
| <a name="module_common_folder_project_details"></a> [common\_folder\_project\_details](#module\_common\_folder\_project\_details) | ../../modules/fabric/projects-data-source | n/a |
| <a name="module_folder_project_details"></a> [folder\_project\_details](#module\_folder\_project\_details) | ../../modules/fabric/projects-data-source | n/a |
| <a name="module_gcs_destinations_as1"></a> [gcs\_destinations\_as1](#module\_gcs\_destinations\_as1) | ../../modules/cft/terraform-google-log-export/modules/storage | n/a |
| <a name="module_log_bucket_destinations_as1"></a> [log\_bucket\_destinations\_as1](#module\_log\_bucket\_destinations\_as1) | ../../modules/cft/terraform-google-log-export/modules/logbucket | n/a |
| <a name="module_log_sinks_as1"></a> [log\_sinks\_as1](#module\_log\_sinks\_as1) | ../../modules/cft/terraform-google-log-export | n/a |

## Resources

| Name | Type |
|------|------|
| [google-beta_google_project_service_identity.destination_project_service_agents](https://registry.terraform.io/providers/hashicorp/google-beta/latest/docs/resources/google_project_service_identity) | resource |
| [google_kms_crypto_key_iam_member.service_agent_cmek](https://registry.terraform.io/providers/hashicorp/google/latest/docs/resources/kms_crypto_key_iam_member) | resource |
| [google_logging_project_bucket_config.default_project_log_buckets_as1](https://registry.terraform.io/providers/hashicorp/google/latest/docs/resources/logging_project_bucket_config) | resource |
| [google_logging_project_sink.default_project_log_sinks_as1](https://registry.terraform.io/providers/hashicorp/google/latest/docs/resources/logging_project_sink) | resource |
| [google_project_iam_member.log_bucket_sink_write_access](https://registry.terraform.io/providers/hashicorp/google/latest/docs/resources/project_iam_member) | resource |
| [google_storage_bucket_iam_member.gcs_sink_write_access](https://registry.terraform.io/providers/hashicorp/google/latest/docs/resources/storage_bucket_iam_member) | resource |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_business_unit"></a> [business\_unit](#input\_business\_unit) | business unit a project belongs to | `string` | n/a | yes |
| <a name="input_cmek"></a> [cmek](#input\_cmek) | project- and region-specific CMEKs for all resource types | `map(map(string))` | n/a | yes |
| <a name="input_labels_common"></a> [labels\_common](#input\_labels\_common) | common labels for every resource | `map(string)` | n/a | yes |
| <a name="input_log_sinks_as1"></a> [log\_sinks\_as1](#input\_log\_sinks\_as1) | org-, folder- or project-level log sinks to create | <pre>map(object({<br/>    destination = object({<br/>      # log buckets<br/>      log_bucket_desc = optional(string)<br/>      retention_days  = optional(number)<br/><br/>      # GCS buckets<br/>      storage_bucket_desc   = optional(string)<br/>      storage_bucket_labels = optional(map(string))<br/>      storage_bucket_lifecycle_rules = optional(set(object({<br/>        action    = map(string)<br/>        condition = map(string)<br/>      })), [])<br/>      storage_class = optional(string)<br/>      versioning    = optional(bool)<br/><br/>      # required attributes<br/>      create_destination = bool<br/>      name               = optional(string)<br/>      project_desc       = string<br/>      type               = string<br/>    })<br/>    exclusions = optional(list(object({<br/>      name        = string,<br/>      description = optional(string),<br/>      filter      = string,<br/>      disabled    = optional(bool, false)<br/>    })), [])<br/>    filter                 = optional(string)<br/>    include_children       = optional(bool, false)<br/>    intercept_children     = optional(bool, false)<br/>    parent_resource_desc   = optional(string, "")<br/>    parent_resource_type   = string<br/>    unique_writer_identity = optional(bool, false)<br/>  }))</pre> | n/a | yes |
| <a name="input_org_id"></a> [org\_id](#input\_org\_id) | organization ID without the `organizations/` prefix | `string` | n/a | yes |
| <a name="input_parent_folder_id"></a> [parent\_folder\_id](#input\_parent\_folder\_id) | ID of the Mutual Funds BU folder | `string` | n/a | yes |
| <a name="input_project_common"></a> [project\_common](#input\_project\_common) | settings common to all projects | `any` | n/a | yes |
| <a name="input_rsrc_prefix"></a> [rsrc\_prefix](#input\_rsrc\_prefix) | resource name prefixes according to naming conventions | `map(string)` | n/a | yes |

## Outputs

No outputs.
<!-- END_TF_DOCS -->