<!-- BEGIN_TF_DOCS -->
## Requirements

No requirements.

## Providers

| Name | Version |
|------|---------|
| <a name="provider_google"></a> [google](#provider\_google) | 6.18.1 |

## Modules

| Name | Source | Version |
|------|--------|---------|
| <a name="module_folder_project_details"></a> [folder\_project\_details](#module\_folder\_project\_details) | ../../../modules/fabric/projects-data-source | n/a |

## Resources

| Name | Type |
|------|------|
| [google_logging_project_bucket_config.default_project_log_buckets_as1](https://registry.terraform.io/providers/hashicorp/google/latest/docs/resources/logging_project_bucket_config) | resource |
| [google_logging_project_sink.default_project_log_sinks_as1](https://registry.terraform.io/providers/hashicorp/google/latest/docs/resources/logging_project_sink) | resource |
| [google_monitoring_monitored_project.metrics_scopes](https://registry.terraform.io/providers/hashicorp/google/latest/docs/resources/monitoring_monitored_project) | resource |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_business_unit"></a> [business\_unit](#input\_business\_unit) | business unit a project belongs to | `string` | n/a | yes |
| <a name="input_cmek"></a> [cmek](#input\_cmek) | project- and region-specific CMEKs for all resource types | `map(map(string))` | n/a | yes |
| <a name="input_environment"></a> [environment](#input\_environment) | app environment a project belongs to | `string` | n/a | yes |
| <a name="input_labels_common"></a> [labels\_common](#input\_labels\_common) | common labels for every resource | `map(string)` | n/a | yes |
| <a name="input_project_common"></a> [project\_common](#input\_project\_common) | settings common to all projects | `any` | n/a | yes |
| <a name="input_rsrc_prefix"></a> [rsrc\_prefix](#input\_rsrc\_prefix) | resource name prefixes according to naming conventions | `map(string)` | n/a | yes |

## Outputs

No outputs.
<!-- END_TF_DOCS -->