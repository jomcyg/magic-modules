# Environment-specific infrastructure

Terraform code (IaC) for MF's environment-specific Google Cloud infrastructure.

## Folder structure

### 01-resource-hierarchy

- env projects
    - enable APIs
    - budget alerts (optional only if value passed in tfvars)
    - delete the Project Owner IAM bindings
    - modify inclusion/exclusion filter in existing _Default log sink
    - create new logSink with Inclusion and Exclusion filter pointing to asia-south2 log bucket
    - create tags (optional only if value passed in tfvars)
    - associate labels (merge common and rsrc specific)
    - disable/delete default service account (with option to individually override)
    - create tags
    - project metadata (e.g. OS-Login TRUE)
- org policy overrides at the BU env folder and env project level
- groups and their associated IAM bindings at the BU env folder and env project level
- essential contact overrides at the BU env folder level
- hierarchical FW policies at the BU env folder level
- Cloud Monitoring metrics scopes

### 02-logging

- log sinks
- log destinations

### 02-security

- Cloud KMS
- Secret Manager

### 02-network

- VPCs - done
- subnets -done
- Serverless VPC connectors - done
- PSA - done
- routes - done 
    (get serverless conn tag name)
- firewalls -done
- sharedvpcservice project - done


- PSC for G APIs --> done
- Cloud DNS private zone --> done
- Cloud NAT --> done


below should be part of CAMS Shared Nw resources code (as trustv and hybric vpc network admin, dns admin permission is required). we can grant the sa of the CAMS shared svc to have custom roles contain vpc peering and dnspeer permission at BU level for better security management
- vpc peering connections --> 
- DNS peering connections