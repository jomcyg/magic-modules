<!-- BEGIN_TF_DOCS -->
## Requirements

No requirements.

## Providers

| Name | Version |
|------|---------|
| <a name="provider_google"></a> [google](#provider\_google) | n/a |

## Modules

No modules.

## Resources

| Name | Type |
|------|------|
| [google_billing_budget.default](https://registry.terraform.io/providers/hashicorp/google/latest/docs/resources/billing_budget) | resource |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_billing_account"></a> [billing\_account](#input\_billing\_account) | billing account ID to create the budget alerts for | `string` | `null` | no |
| <a name="input_budget_alerts"></a> [budget\_alerts](#input\_budget\_alerts) | billing budget alerts to create | <pre>map(object({<br>    amount = object({<br>      currency_code   = optional(string)<br>      nanos           = optional(number)<br>      units           = optional(number)<br>      use_last_period = optional(bool)<br>    })<br>    display_name = optional(string)<br>    filter = optional(object({<br>      credit_types_treatment = optional(object({<br>        exclude_all       = optional(bool)<br>        include_specified = optional(list(string))<br>      }))<br>      label = optional(object({<br>        key   = string<br>        value = string<br>      }))<br>      period = optional(object({<br>        calendar = optional(string)<br>        custom = optional(object({<br>          start_date = object({<br>            day   = number<br>            month = number<br>            year  = number<br>          })<br>          end_date = optional(object({<br>            day   = number<br>            month = number<br>            year  = number<br>          }))<br>        }))<br>      }))<br>      services = optional(list(string))<br>    }), {})<br>    threshold_rules = optional(list(object({<br>      percent          = number<br>      forecasted_spend = optional(bool)<br>    })), [])<br>  }))</pre> | `{}` | no |
| <a name="input_projects"></a> [projects](#input\_projects) | list of projects to create a budget alert for in the format, projects/PROJECT\_NUMBER | `list(string)` | `[]` | no |
| <a name="input_resource_ancestors"></a> [resource\_ancestors](#input\_resource\_ancestors) | list of folders / organization to create a budget alert for in the format, folders/FOLDER\_ID or organizations/ORG\_ID | `list(string)` | `[]` | no |

## Outputs

No outputs.
<!-- END_TF_DOCS -->