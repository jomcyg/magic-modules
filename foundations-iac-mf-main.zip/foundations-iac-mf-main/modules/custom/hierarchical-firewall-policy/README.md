<!-- BEGIN_TF_DOCS -->
## Requirements

No requirements.

## Providers

| Name | Version |
|------|---------|
| <a name="provider_google"></a> [google](#provider\_google) | n/a |
| <a name="provider_google-beta"></a> [google-beta](#provider\_google-beta) | n/a |

## Modules

No modules.

## Resources

| Name | Type |
|------|------|
| [google-beta_google_compute_firewall_policy_with_rules.firewall_policy_with_rules](https://registry.terraform.io/providers/hashicorp/google-beta/latest/docs/resources/google_compute_firewall_policy_with_rules) | resource |
| [google_compute_firewall_policy_association.firewall_policy_association](https://registry.terraform.io/providers/hashicorp/google/latest/docs/resources/compute_firewall_policy_association) | resource |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_hierarchical_firewall_policies"></a> [hierarchical\_firewall\_policies](#input\_hierarchical\_firewall\_policies) | hierarchical firewall policies to create and attach to a folder / org | <pre>map(object({<br>    rules = map(object({<br>      action         = string<br>      direction      = string<br>      enable_logging = optional(bool, false)<br>      match = object({<br>        src_ip_ranges  = optional(list(string))<br>        dest_ip_ranges = optional(list(string))<br>        layer4_config = object({<br>          ip_protocol = optional(string, "tcp")<br>          ports       = optional(list(number))<br>        })<br>      })<br>      priority                = number<br>      target_resources        = optional(list(string))<br>      target_service_accounts = optional(list(string))<br>    }))<br>  }))</pre> | `{}` | no |
| <a name="input_parent_id"></a> [parent\_id](#input\_parent\_id) | folder or organization ID to create the policy for | `string` | n/a | yes |

## Outputs

No outputs.
<!-- END_TF_DOCS -->