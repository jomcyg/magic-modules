# Upgrading to Log Export v10.0

## Provider version
- The v10.0 release of Log Export is a backwards incompatible release and features a new feature `intercept_children` for folder and organization logging sinks. Minimum provider version `5.27` ia required.
- Allows maximum provider version 6+

## Terraform version
- Terraform version 1.3+ required
