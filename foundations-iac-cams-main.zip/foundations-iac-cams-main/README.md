# Infrastructure as code (Terraform) for the organization

Terraform code (IaC) for CAMS' organization-level Google Cloud infrastructure.

## Folder structure

### 01-general

- general org-level resources:
    - essential contacts
    - budget alerts
    - hierarchical firewall policies

### 01-org-policy

- org policies at the org level

### 01-iam-groups

- groups and their associated IAM bindings at the org level

### 02-logging

- log sinks at the org level
- log destinations (GCS or log buckets)

### 02-security

- security resources at the org level (if any)

### 02-shared-services

#### 01-resource-hierarchy

- folders and subfolders for shared services
    - delete the Folder Admin IAM bindings
    - budget alerts
- projects for shared services
    - enable APIs
    - budget alerts
    - disable the _Default log sink
    - delete the Project Owner IAM bindings
- org policy overrides at the folder and project level for shared services
- groups and their associated IAM bindings at the folder and project level for shared services
- billing data export to BQ

#### 02-logging

- log sinks
- log destinations

#### 02-security

- Artifact Registry
- Certificate Authority Service (CAS)
- Cloud KMS
- Secret Manager

#### 02-quota-monitoring

- https://github.com/google/quota-monitoring-solution?tab=readme-ov-file#2-architecture

#### 02-network-lz-prod

- VPCs
- subnets
- peering connections
- PSA
- Serverless VPC connectors
- PSC for G APIs
- Cloud DNS private zones, peering zones and record sets
- routes
- firewalls
- Cloud NAT
- Cloud Armor policies
- external regional ALBs
- internal regional passthrough NLBs
- VMs

#### 02-network-lz-nonprod

- VPCs
- subnets
- peering connections
- PSA
- Serverless VPC connectors
- PSC for G APIs
- Cloud DNS private zones, peering zones and record sets
- routes
- firewalls
- Cloud NAT
- Cloud Armor policies
- external regional ALBs
- internal regional passthrough NLBs
- VMs
