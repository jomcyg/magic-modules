<!-- BEGIN_TF_DOCS -->
## Requirements

No requirements.

## Providers

| Name | Version |
|------|---------|
| <a name="provider_google"></a> [google](#provider\_google) | 6.17.0 |

## Modules

| Name | Source | Version |
|------|--------|---------|
| <a name="module_org_level_budget_alerts"></a> [org\_level\_budget\_alerts](#module\_org\_level\_budget\_alerts) | ../modules/custom/budget-alert | n/a |
| <a name="module_org_level_hierarchical_firewall_policies"></a> [org\_level\_hierarchical\_firewall\_policies](#module\_org\_level\_hierarchical\_firewall\_policies) | ../modules/custom/hierarchical-firewall-policy | n/a |

## Resources

| Name | Type |
|------|------|
| [google_essential_contacts_contact.org_level_contacts](https://registry.terraform.io/providers/hashicorp/google/latest/docs/resources/essential_contacts_contact) | resource |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_billing_account_name"></a> [billing\_account\_name](#input\_billing\_account\_name) | billing account ID to create the budget alerts for | `string` | `null` | no |
| <a name="input_business_unit"></a> [business\_unit](#input\_business\_unit) | business unit a project belongs to | `string` | n/a | yes |
| <a name="input_cmek"></a> [cmek](#input\_cmek) | project- and region-specific CMEKs for all resource types | `map(map(string))` | n/a | yes |
| <a name="input_labels_common"></a> [labels\_common](#input\_labels\_common) | common labels for every resource | `map(string)` | n/a | yes |
| <a name="input_org_id"></a> [org\_id](#input\_org\_id) | organization ID without the `organizations/` prefix | `string` | n/a | yes |
| <a name="input_org_level_budget_alerts"></a> [org\_level\_budget\_alerts](#input\_org\_level\_budget\_alerts) | billing budget alerts to create at the org level | <pre>map(object({<br/>    amount = object({<br/>      currency_code   = optional(string)<br/>      nanos           = optional(number)<br/>      units           = optional(number)<br/>      use_last_period = optional(bool)<br/>    })<br/>    filter = optional(object({<br/>      credit_types_treatment = optional(object({<br/>        exclude_all       = optional(bool)<br/>        include_specified = optional(list(string))<br/>      }))<br/>      label = optional(object({<br/>        key   = string<br/>        value = string<br/>      }))<br/>      period = optional(object({<br/>        calendar = optional(string)<br/>        custom = optional(object({<br/>          start_date = object({<br/>            day   = number<br/>            month = number<br/>            year  = number<br/>          })<br/>          end_date = optional(object({<br/>            day   = number<br/>            month = number<br/>            year  = number<br/>          }))<br/>        }))<br/>      }))<br/>      services = optional(list(string))<br/>    }))<br/>    threshold_rules = optional(list(object({<br/>      percent          = number<br/>      forecasted_spend = optional(bool)<br/>    })), [])<br/>  }))</pre> | `{}` | no |
| <a name="input_org_level_essential_contacts"></a> [org\_level\_essential\_contacts](#input\_org\_level\_essential\_contacts) | Map of email to notification categories | `map(list(string))` | `{}` | no |
| <a name="input_org_level_hierarchical_firewall_policies"></a> [org\_level\_hierarchical\_firewall\_policies](#input\_org\_level\_hierarchical\_firewall\_policies) | list of hierarchical firewall policies to create at the org level | <pre>map(object({<br/>    rules = map(object({<br/>      action         = string<br/>      description    = string<br/>      direction      = string<br/>      enable_logging = optional(bool, false)<br/>      match = object({<br/>        src_ip_ranges  = optional(list(string), [])<br/>        dest_ip_ranges = optional(list(string), [])<br/>        layer4_config = object({<br/>          ip_protocol = optional(string, "tcp")<br/>          ports       = optional(list(number), [])<br/>        })<br/>      })<br/>      priority                = number<br/>      target_resources        = optional(list(string), [])<br/>      target_service_accounts = optional(list(string), [])<br/>    }))<br/>  }))</pre> | `{}` | no |
| <a name="input_project_common"></a> [project\_common](#input\_project\_common) | settings common to all projects | `any` | n/a | yes |
| <a name="input_rsrc_prefix"></a> [rsrc\_prefix](#input\_rsrc\_prefix) | resource name prefixes according to naming conventions | `map(string)` | n/a | yes |

## Outputs

No outputs.
<!-- END_TF_DOCS -->