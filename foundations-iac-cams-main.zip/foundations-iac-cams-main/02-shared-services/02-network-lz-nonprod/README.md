<!-- BEGIN_TF_DOCS -->
## Requirements

No requirements.

## Providers

| Name | Version |
|------|---------|
| <a name="provider_google"></a> [google](#provider\_google) | 6.17.0 |

## Modules

| Name | Source | Version |
|------|--------|---------|
| <a name="module_nat_external_ips_as1"></a> [nat\_external\_ips\_as1](#module\_nat\_external\_ips\_as1) | ../../modules/fabric/net-address | n/a |
| <a name="module_nat_external_ips_as2"></a> [nat\_external\_ips\_as2](#module\_nat\_external\_ips\_as2) | ../../modules/fabric/net-address | n/a |
| <a name="module_nats_as1"></a> [nats\_as1](#module\_nats\_as1) | ../../modules/fabric/net-cloudnat | n/a |
| <a name="module_nats_as2"></a> [nats\_as2](#module\_nats\_as2) | ../../modules/fabric/net-cloudnat | n/a |
| <a name="module_peering_dns"></a> [peering\_dns](#module\_peering\_dns) | ../../modules/fabric/dns | n/a |
| <a name="module_peering_to_vpchybridconn"></a> [peering\_to\_vpchybridconn](#module\_peering\_to\_vpchybridconn) | ../../modules/fabric/net-vpc-peering | n/a |
| <a name="module_private_dns"></a> [private\_dns](#module\_private\_dns) | ../../modules/fabric/dns | n/a |
| <a name="module_project_details"></a> [project\_details](#module\_project\_details) | ../../modules/fabric/projects-data-source | n/a |
| <a name="module_pscgapi_private_dns"></a> [pscgapi\_private\_dns](#module\_pscgapi\_private\_dns) | ../../modules/fabric/dns | n/a |
| <a name="module_routes_as1"></a> [routes\_as1](#module\_routes\_as1) | ../../modules/fabric/net-vpc | n/a |
| <a name="module_routes_as2"></a> [routes\_as2](#module\_routes\_as2) | ../../modules/fabric/net-vpc | n/a |
| <a name="module_subnets_as1"></a> [subnets\_as1](#module\_subnets\_as1) | ../../modules/fabric/net-vpc | n/a |
| <a name="module_subnets_as2"></a> [subnets\_as2](#module\_subnets\_as2) | ../../modules/fabric/net-vpc | n/a |
| <a name="module_vpc"></a> [vpc](#module\_vpc) | ../../modules/fabric/net-vpc | n/a |

## Resources

| Name | Type |
|------|------|
| [google_compute_global_address.pscgapi](https://registry.terraform.io/providers/hashicorp/google/latest/docs/resources/compute_global_address) | resource |
| [google_compute_global_forwarding_rule.pscgapi](https://registry.terraform.io/providers/hashicorp/google/latest/docs/resources/compute_global_forwarding_rule) | resource |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_business_unit"></a> [business\_unit](#input\_business\_unit) | business unit a project belongs to | `string` | n/a | yes |
| <a name="input_cmek"></a> [cmek](#input\_cmek) | project- and region-specific CMEKs for all resource types | `map(map(string))` | n/a | yes |
| <a name="input_environment"></a> [environment](#input\_environment) | app environment a project belongs to | `string` | n/a | yes |
| <a name="input_hybridconn_project_id"></a> [hybridconn\_project\_id](#input\_hybridconn\_project\_id) | HybridConn project ID. the value should be one of from prod or nonprod , as applicable | `string` | n/a | yes |
| <a name="input_labels_common"></a> [labels\_common](#input\_labels\_common) | common labels for every resource | `map(string)` | n/a | yes |
| <a name="input_nats_as1"></a> [nats\_as1](#input\_nats\_as1) | List of NAT configurations for specific region | <pre>map(object({<br/>    project_desc = string<br/>    nat = optional(object({<br/>      region_short_code     = string<br/>      region                = string<br/>      total_static_ip_count = number<br/>      source_ips_num        = list(string)<br/>      config_source_subnetworks = optional(object({<br/>        all_subnets                        = optional(bool, true)<br/>        only_primary_ranges_of_all_subnets = optional(bool, false)<br/>      }))<br/>      config_port_allocation = optional(object({<br/>        enable_endpoint_independent_mapping = optional(bool)<br/>        enable_dynamic_port_allocation      = optional(bool)<br/>        min_ports_per_vm                    = optional(number)<br/>        max_ports_per_vm                    = optional(number)<br/>      }))<br/>      config_timeouts = optional(object({<br/>        icmp            = optional(number, 30)<br/>        tcp_established = optional(number, 1200)<br/>        tcp_time_wait   = optional(number, 120)<br/>        tcp_transitory  = optional(number, 30)<br/>        udp             = optional(number, 30)<br/>      }))<br/>      logging_filter = optional(string, "ERRORS_ONLY")<br/>      rules = optional(list(object({<br/>        description    = optional(string)<br/>        match          = optional(string)<br/>        source_ips_num = optional(list(string))<br/>      })))<br/>    }))<br/>  }))</pre> | n/a | yes |
| <a name="input_nats_as2"></a> [nats\_as2](#input\_nats\_as2) | List of NAT configurations for specific region | <pre>map(object({<br/>    project_desc = string<br/>    nat = optional(object({<br/>      region_short_code     = string<br/>      region                = string<br/>      total_static_ip_count = number<br/>      source_ips_num        = list(string)<br/>      config_source_subnetworks = optional(object({<br/>        all_subnets                        = optional(bool, true)<br/>        only_primary_ranges_of_all_subnets = optional(bool, false)<br/>      }))<br/>      config_port_allocation = optional(object({<br/>        enable_endpoint_independent_mapping = optional(bool)<br/>        enable_dynamic_port_allocation      = optional(bool)<br/>        min_ports_per_vm                    = optional(number)<br/>        max_ports_per_vm                    = optional(number)<br/>      }))<br/>      config_timeouts = optional(object({<br/>        icmp            = optional(number, 30)<br/>        tcp_established = optional(number, 1200)<br/>        tcp_time_wait   = optional(number, 120)<br/>        tcp_transitory  = optional(number, 30)<br/>        udp             = optional(number, 30)<br/>      }))<br/>      logging_filter = optional(string, "ERRORS_ONLY")<br/>      rules = optional(list(object({<br/>        description    = optional(string)<br/>        match          = optional(string)<br/>        source_ips_num = optional(list(string))<br/>      })))<br/>    }))<br/>  }))</pre> | n/a | yes |
| <a name="input_project_common"></a> [project\_common](#input\_project\_common) | settings common to all projects | `any` | n/a | yes |
| <a name="input_pscgapi"></a> [pscgapi](#input\_pscgapi) | ######################## Declare Variable for VPC  PSC for GoogleApi which should be defined in tfvars.json | <pre>map(object({<br/>    project_desc      = string<br/>    global_ip_address = string<br/>    target            = string<br/>    private_zone      = list(string)<br/>  }))</pre> | n/a | yes |
| <a name="input_routes_as1"></a> [routes\_as1](#input\_routes\_as1) | List of VPC route configurations for specific region | <pre>map(object({<br/>    project_desc = string<br/>    routes = optional(map(object({<br/>      route_name_token_desc = string<br/>      description           = string<br/>      dest_range            = string<br/>      tags                  = optional(list(string), [])<br/>      next_hop_type         = string<br/>      next_hop_project_id   = string<br/>      next_hop              = string<br/>      priority              = number<br/>    })))<br/>  }))</pre> | n/a | yes |
| <a name="input_routes_as2"></a> [routes\_as2](#input\_routes\_as2) | List of VPC route configurations for specific region | <pre>map(object({<br/>    project_desc = string<br/>    routes = optional(map(object({<br/>      route_name_token_desc = string<br/>      description           = string<br/>      dest_range            = string<br/>      tags                  = optional(list(string), [])<br/>      next_hop_type         = string<br/>      next_hop_project_id   = string<br/>      next_hop              = string<br/>      priority              = number<br/>    })))<br/>  }))</pre> | n/a | yes |
| <a name="input_rsrc_prefix"></a> [rsrc\_prefix](#input\_rsrc\_prefix) | resource name prefixes according to naming conventions | `map(string)` | n/a | yes |
| <a name="input_subnets_as1"></a> [subnets\_as1](#input\_subnets\_as1) | List of subnet configurations for asia-south1 | <pre>map(object({<br/>    project_desc = string<br/>    subnets = optional(list(object({<br/>      subnet_name_token_desc_regioncode = string<br/>      region                            = string<br/>      description                       = string<br/>      enable_private_access             = optional(bool, true)<br/>      ip_cidr_range                     = string<br/>      secondary_ip_ranges               = optional(map(string), {})<br/>      flow_logs_config = optional(object({<br/>        flow_sampling        = number<br/>        aggregation_interval = string<br/>      }))<br/>    })), [])<br/>    subnets_proxy_only = optional(list(object({<br/>      ip_cidr_range                     = string<br/>      subnet_name_token_desc_regioncode = string<br/>      region                            = string<br/>      active                            = bool<br/>      global                            = bool<br/>    })), [])<br/>    subnets_psc = optional(list(object({<br/>      subnet_name_token_desc_regioncode = string<br/>      ip_cidr_range                     = string<br/>      region                            = string<br/>    })), [])<br/>  }))</pre> | n/a | yes |
| <a name="input_subnets_as2"></a> [subnets\_as2](#input\_subnets\_as2) | List of subnet configurations for asia-south1 | <pre>map(object({<br/>    project_desc = string<br/>    subnets = optional(list(object({<br/>      subnet_name_token_desc_regioncode = string<br/>      region                            = string<br/>      description                       = string<br/>      enable_private_access             = optional(bool, true)<br/>      ip_cidr_range                     = string<br/>      secondary_ip_ranges               = optional(map(string), {})<br/>      flow_logs_config = optional(object({<br/>        flow_sampling        = number<br/>        aggregation_interval = string<br/>      }))<br/>    })), [])<br/>    subnets_proxy_only = optional(list(object({<br/>      ip_cidr_range                     = string<br/>      subnet_name_token_desc_regioncode = string<br/>      region                            = string<br/>      active                            = bool<br/>      global                            = bool<br/>    })), [])<br/>    subnets_psc = optional(list(object({<br/>      subnet_name_token_desc_regioncode = string<br/>      ip_cidr_range                     = string<br/>      region                            = string<br/>    })), [])<br/>  }))</pre> | n/a | yes |
| <a name="input_vpc"></a> [vpc](#input\_vpc) | VPC and its associated global resources lile PSA, Routes, Firewall, SharedVPC | <pre>map(object({<br/>    project_desc                           = string<br/>    routing_mode                           = optional(string, "GLOBAL")<br/>    description                            = optional(string, "VPC Network")<br/>    mtu                                    = optional(number, 1460)<br/>    delete_default_internet_gateway_routes = optional(bool, true)<br/><br/>    psa_configs = optional(list(object({<br/>      ranges          = map(string)<br/>      range_prefix    = optional(string, "")<br/>      deletion_policy = optional(string, "ABANDON")<br/>      export_routes   = optional(bool, true)<br/>      import_routes   = optional(bool, true)<br/>    })), [])<br/><br/>    routes = optional(map(object({<br/>      route_name_token_desc = string<br/>      description           = string<br/>      dest_range            = optional(string, "")<br/>      tags                  = optional(list(string), [])<br/>      next_hop_type         = string<br/>      next_hop_project_desc = string<br/>      next_hop              = string<br/>      priority              = number<br/>    })))<br/><br/>    firewall = optional(object({<br/>      egress_rules = optional(map(object({<br/>        deny               = bool<br/>        description        = string<br/>        source_ranges      = optional(list(string))<br/>        destination_ranges = optional(list(string))<br/>        priority           = optional(number)<br/>        targets            = optional(list(string))<br/>        rules = optional(list(object({<br/>          protocol = optional(string)<br/>          ports    = optional(list(number))<br/>        })))<br/>      })))<br/>      ingress_rules = optional(map(object({<br/>        deny                           = optional(bool)<br/>        description                    = optional(string)<br/>        source_ranges                  = optional(list(string))<br/>        destination_ranges             = optional(list(string))<br/>        priority                       = optional(number)<br/>        projects_data_source_parent_id = optional(list(string))<br/>        destination                    = optional(list(string))<br/>        rules = optional(list(object({<br/>          protocol = optional(string)<br/>          ports    = optional(list(number))<br/>        })))<br/>      })))<br/>    }))<br/><br/>    service_project_desc = optional(list(string), [])<br/>  }))</pre> | n/a | yes |
| <a name="input_vpc_hybridconn_self_link"></a> [vpc\_hybridconn\_self\_link](#input\_vpc\_hybridconn\_self\_link) | The hybrid connectivity VPC Selflinks - will be referred for vpc peering | `string` | n/a | yes |

## Outputs

No outputs.
<!-- END_TF_DOCS -->

## VPC resources by location type

### Global

- vpc (desc, mtu, routing mode etc)
- psa
- serviceprojects
- dnszone
- vpcpeering

### Regional

- subnet
- serverlessvpcconn

### Global with regional attributes

- firewall rules with regional IPs
- routes with regional ilb nexthops
- dnzrecordset can contain regional IPs
