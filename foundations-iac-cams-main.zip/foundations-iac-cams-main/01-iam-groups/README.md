<!-- BEGIN_TF_DOCS -->
## Requirements

No requirements.

## Providers

No providers.

## Modules

| Name | Source | Version |
|------|--------|---------|
| <a name="module_groups"></a> [groups](#module\_groups) | ../modules/cft/terraform-google-group | n/a |
| <a name="module_org_level_iam_bindings"></a> [org\_level\_iam\_bindings](#module\_org\_level\_iam\_bindings) | ../modules/cft/terraform-google-iam/modules/organizations_iam | n/a |

## Resources

No resources.

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_business_unit"></a> [business\_unit](#input\_business\_unit) | business unit a project belongs to | `string` | n/a | yes |
| <a name="input_cmek"></a> [cmek](#input\_cmek) | project- and region-specific CMEKs for all resource types | `map(map(string))` | n/a | yes |
| <a name="input_environment"></a> [environment](#input\_environment) | app environment a project belongs to | `string` | n/a | yes |
| <a name="input_groups"></a> [groups](#input\_groups) | list of IAM groups to create | <pre>map(object(<br/>    {<br/>      domain   = string<br/>      id       = string<br/>      managers = optional(list(string), [])<br/>      members  = optional(list(string), [])<br/>      owners   = optional(list(string), [])<br/>    }<br/>  ))</pre> | n/a | yes |
| <a name="input_labels_common"></a> [labels\_common](#input\_labels\_common) | common labels for every resource | `map(string)` | n/a | yes |
| <a name="input_org_id"></a> [org\_id](#input\_org\_id) | organization ID without the `organizations/` prefix | `string` | n/a | yes |
| <a name="input_org_level_iam_bindings"></a> [org\_level\_iam\_bindings](#input\_org\_level\_iam\_bindings) | org-level IAM bindings for groups | `map(list(string))` | n/a | yes |
| <a name="input_project_common"></a> [project\_common](#input\_project\_common) | settings common to all projects | `any` | n/a | yes |
| <a name="input_rsrc_prefix"></a> [rsrc\_prefix](#input\_rsrc\_prefix) | resource name prefixes according to naming conventions | `map(string)` | n/a | yes |

## Outputs

| Name | Description |
|------|-------------|
| <a name="output_groups"></a> [groups](#output\_groups) | attributes of groups created (ref. - modules/cft/terraform-google-group/outputs.tf) |
<!-- END_TF_DOCS -->